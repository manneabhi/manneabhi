1. In present directory where the new proejct is created, use the command "python manage.py runserver" to run the local web server.

2. An URL will be obtian. 

3. Put the obtain URL in the local web brower.

4. After running the Python file a message of Hello World! is displayed in the web browser. 